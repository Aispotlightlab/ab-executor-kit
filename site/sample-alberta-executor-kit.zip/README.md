# Alberta Executor Kit

Generated for date of death 2026-09-01.

Files: 00-task-checklist.csv (dated), 01-expenses.csv (claim reimbursement from the estate), 02-assets.csv (date-of-death inventory), 03-distributions.csv.

One-time purchase, no subscription, nothing to cancel. Plain CSV: opens in Excel, Numbers, Google Sheets or LibreOffice and stays yours offline.

DISCLAIMER: This kit is an organizer, not legal advice. Executor duties in Alberta are governed by the Estate Administration Act and the Surrogate Rules; confirm deadlines with a lawyer or the Court of King's Bench Surrogate office.

SAMPLE: this zip shows the first 6 of 19 dated tasks for a fictional 2026-09-01 date of death. The full kit is generated for your date of death.
